from .models import Contact
from django import forms


#for contact us page
class ContactForm(forms.Form):
    class Meta:
        model=Contact
        field='__all__'


